Note: This application was built and run on Linux Mint

How to Build:



1. Compile the application by entering 'make' in a terminal opened to the folder



How to Run: 



1. Run the application by entering './CraneProject' or double clicking the CraneProject file in the folder
